# aiogram-bot-template
aiogram is a pretty simple and fully asynchronous framework for Telegram Bot API written in Python 3.7 with asyncio and aiohttp.<br> 
It helps you to make your bots faster and simpler.
